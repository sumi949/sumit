// questions.js
// This file contains the question data for the quiz.
// In a real-world scenario, this data could be fetched from an API.

const questions = [
    {
        id: 1,
        question: "Which keyword is used to define a function in Python?",
        options: ["func", "def", "function", "define"],
        correctAnswer: 1 // Index 1 -> "def"
    },
    {
        id: 2,
        question: "What is the output of print(2 ** 3)?",
        options: ["6", "8", "9", "5"],
        correctAnswer: 1 // Index 1 -> "8"
    },
    {
        id: 3,
        question: "Which data type is used to store True or False in Python?",
        options: ["String", "Integer", "Boolean", "Float"],
        correctAnswer: 2 // Index 2 -> "Boolean"
    },
    {
        id: 4,
        question: "Which of the following is a mutable data type?",
        options: ["Tuple", "List", "String", "Integer"],
        correctAnswer: 1 // Index 1 -> "List"
    },
    {
        id: 5,
        question: "How do you start a comment in Python?",
        options: ["//", "/*", "#", "<!--"],
        correctAnswer: 2 // Index 2 -> "#"
    },
    {
        id: 6,
        question: "Which function is used to get the length of a list?",
        options: ["length()", "len()", "size()", "count()"],
        correctAnswer: 1 // Index 1 -> "len()"
    },
    {
        id: 7,
        question: "What is the correct file extension for Python files?",
        options: [".py", ".pt", ".pyt", ".python"],
        correctAnswer: 0 // Index 0 -> ".py"
    },
    {
        id: 8,
        question: "Which logical operator returns True if both statements are true?",
        options: ["or", "not", "and", "xor"],
        correctAnswer: 2 // Index 2 -> "and"
    },
    {
        id: 9,
        question: "Which loop is used to iterate over a sequence?",
        options: ["while", "for", "do-while", "repeat"],
        correctAnswer: 1 // Index 1 -> "for"
    },
    {
        id: 10,
        question: "What is the result of 10 // 3 in Python?",
        options: ["3.33", "3", "3.0", "1"],
        correctAnswer: 1 // Index 1 -> "3" (Floor division)
    },
    {
        id: 11,
        question: "Which keyword is used to create a class in Python?",
        options: ["function", "class", "define", "object"],
        correctAnswer: 1
    },
    {
        id: 12,
        question: "What does the 'break' statement do?",
        options: ["Skips one iteration", "Stops the loop completely", "Restarts loop", "Pauses loop"],
        correctAnswer: 1
    },
    {
        id: 13,
        question: "What is the output of print(type(5))?",
        options: ["int", "<class 'int'>", "integer", "number"],
        correctAnswer: 1
    },
    {
        id: 14,
        question: "Which method adds an item to the end of a list?",
        options: ["add()", "append()", "insert()", "push()"],
        correctAnswer: 1
    },
    {
        id: 15,
        question: "How do you create a dictionary in Python?",
        options: ["[]", "()", "{}", "<>"],
        correctAnswer: 2
    },
    {
        id: 16,
        question: "Which operator is used for equality comparison?",
        options: ["=", "==", "!=", "==="],
        correctAnswer: 1
    },
    {
        id: 17,
        question: "What is the output of print(10 % 3)?",
        options: ["3", "1", "0", "3.33"],
        correctAnswer: 1
    },
    {
        id: 18,
        question: "Which function converts a string to an integer?",
        options: ["str()", "int()", "float()", "convert()"],
        correctAnswer: 1
    },
    {
        id: 19,
        question: "Which keyword is used for exception handling?",
        options: ["error", "catch", "try", "handle"],
        correctAnswer: 2
    },
    {
        id: 20,
        question: "Which statement is used to handle exceptions?",
        options: ["try-except", "if-else", "for-while", "switch-case"],
        correctAnswer: 0
    },
    {
        id: 21,
        question: "What is the output of bool(0)?",
        options: ["True", "False", "0", "Error"],
        correctAnswer: 1
    },
    {
        id: 22,
        question: "Which function is used to take user input?",
        options: ["scan()", "input()", "read()", "get()"],
        correctAnswer: 1
    },
    {
        id: 23,
        question: "What is the correct way to create a tuple?",
        options: ["[1,2,3]", "{1,2,3}", "(1,2,3)", "<1,2,3>"],
        correctAnswer: 2
    },
    {
        id: 24,
        question: "Which keyword is used to import a module?",
        options: ["include", "using", "import", "require"],
        correctAnswer: 2
    },
    {
        id: 25,
        question: "What is the output of print(5 > 3 and 2 < 1)?",
        options: ["True", "False", "None", "Error"],
        correctAnswer: 1
    },
    {
        id: 26,
        question: "Which built-in data type is unordered?",
        options: ["List", "Tuple", "Dictionary", "String"],
        correctAnswer: 2
    },
    {
        id: 27,
        question: "Which keyword is used to return a value from a function?",
        options: ["output", "return", "give", "print"],
        correctAnswer: 1
    },
    {
        id: 28,
        question: "What is the output of print(len('Python'))?",
        options: ["5", "6", "7", "Error"],
        correctAnswer: 1
    },
    {
        id: 29,
        question: "Which of the following is NOT a Python data type?",
        options: ["Set", "Array", "Dictionary", "Tuple"],
        correctAnswer: 1
    },
    {
        id: 30,
        question: "Which keyword is used to define a lambda function?",
        options: ["func", "lambda", "def", "map"],
        correctAnswer: 1
    }
];
