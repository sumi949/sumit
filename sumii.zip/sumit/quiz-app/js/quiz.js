// quiz.js
// Core Quiz Engine Logic

class Quiz {
    constructor(questions) {
        this.questions = questions;
        this.score = 0;
        this.currentQuestionIndex = 0;
        this.username = "";
    }

    // Start the quiz with a user name
    start(name) {
        this.username = name;
        this.score = 0;
        this.currentQuestionIndex = 0;
    }

    // Get the current question object
    getCurrentQuestion() {
        return this.questions[this.currentQuestionIndex];
    }

    // Check if the answer is correct
    checkAnswer(selectedIndex) {
        const currentQuestion = this.getCurrentQuestion();
        if (selectedIndex === currentQuestion.correctAnswer) {
            this.score++;
            return true;
        }
        return false;
    }

    // Move to the next question
    nextQuestion() {
        this.currentQuestionIndex++;
    }

    // Check if the quiz has ended
    hasEnded() {
        return this.currentQuestionIndex >= this.questions.length;
    }

    // Calculate percentage
    getPercentage() {
        return Math.round((this.score / this.questions.length) * 100);
    }

    // Get restart state
    reset() {
        this.score = 0;
        this.currentQuestionIndex = 0;
    }
}

// Initialize the Quiz instance
const quiz = new Quiz(questions);
