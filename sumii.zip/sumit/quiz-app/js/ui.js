// ui.js
// Handles all DOM manipulation and UI updates

// --- DOM Elements ---
const welcomeScreen = document.getElementById('welcome-screen');
const quizScreen = document.getElementById('quiz-screen');
const resultScreen = document.getElementById('result-screen');

const usernameInput = document.getElementById('username');
const startBtn = document.getElementById('start-btn');
const errorMessage = document.getElementById('error-message');

const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const questionCounter = document.getElementById('question-counter');
const scoreDisplay = document.getElementById('score-display');
const nextBtn = document.getElementById('next-btn');

const resultName = document.getElementById('result-name');
const finalScore = document.getElementById('final-score');
const totalQuestions = document.getElementById('total-questions');
const percentageDisplay = document.getElementById('percentage');
const performanceMsg = document.getElementById('performance-msg');
const restartBtn = document.getElementById('restart-btn');

// --- Event Listeners ---

// Start Quiz
startBtn.addEventListener('click', () => {
    const name = usernameInput.value.trim();
    if (name === "") {
        errorMessage.classList.remove('hidden');
    } else {
        errorMessage.classList.add('hidden');
        quiz.start(name);
        showScreen(quizScreen);
        loadQuestion();
    }
});

// Restart Quiz
restartBtn.addEventListener('click', () => {
    quiz.reset();
    showScreen(welcomeScreen);
    usernameInput.value = ""; // Clear name input
});

// Next Question
nextBtn.addEventListener('click', () => {
    quiz.nextQuestion();
    if (quiz.hasEnded()) {
        showResult();
    } else {
        loadQuestion();
    }
});

// --- Helper Functions ---

// Switch visible screen
function showScreen(screen) {
    welcomeScreen.classList.add('hidden');
    quizScreen.classList.add('hidden');
    resultScreen.classList.add('hidden');
    screen.classList.remove('hidden');
}

// Load current question to UI
function loadQuestion() {
    const currentQuestion = quiz.getCurrentQuestion();

    // Update Text
    questionText.innerText = `${quiz.currentQuestionIndex + 1}. ${currentQuestion.question}`;
    questionCounter.innerText = `Question ${quiz.currentQuestionIndex + 1} of ${quiz.questions.length}`;
    scoreDisplay.innerText = `Score: ${quiz.score}`;

    // Clear previous options
    optionsContainer.innerHTML = '';

    // Create Option Buttons
    currentQuestion.options.forEach((option, index) => {
        const btn = document.createElement('button');
        btn.innerText = option;
        btn.classList.add('option-btn');
        btn.addEventListener('click', () => selectOption(index, btn));
        optionsContainer.appendChild(btn);
    });

    // Hide Next Button initially
    nextBtn.classList.add('hidden');
}

// Handle Option Selection
function selectOption(selectedIndex, btn) {
    const currentQuestion = quiz.getCurrentQuestion();
    const isCorrect = quiz.checkAnswer(selectedIndex);

    // Visual Feedback
    if (isCorrect) {
        btn.classList.add('correct');
    } else {
        btn.classList.add('incorrect');
        // Highlight correct answer
        const allOptions = optionsContainer.children;
        allOptions[currentQuestion.correctAnswer].classList.add('correct');
    }

    // Disable all buttons
    const allOptions = Array.from(optionsContainer.children);
    allOptions.forEach(button => button.disabled = true);

    // Show Next Button
    nextBtn.classList.remove('hidden');

    // Update Score UI immediately
    scoreDisplay.innerText = `Score: ${quiz.score}`;
}

// Show Result Screen
function showResult() {
    showScreen(resultScreen);

    resultName.innerText = quiz.username;
    finalScore.innerText = quiz.score;
    totalQuestions.innerText = quiz.questions.length;

    const percentage = quiz.getPercentage();
    percentageDisplay.innerText = `${percentage}%`;

    // Performance Message
    if (percentage >= 80) {
        performanceMsg.innerText = "Excellent! You're a pro!";
        performanceMsg.style.color = "#2ecc71";
    } else if (percentage >= 60) {
        performanceMsg.innerText = "Good Job! Keep it up.";
        performanceMsg.style.color = "#3498db";
    } else if (percentage >= 40) {
        performanceMsg.innerText = "Nice try! Review and try again.";
        performanceMsg.style.color = "#f39c12";
    } else {
        performanceMsg.innerText = "Better luck next time!";
        performanceMsg.style.color = "#e74c3c";
    }
}
